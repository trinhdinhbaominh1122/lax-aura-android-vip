package com.laxaura.ios

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 12, 27)
    private val panel = Color.rgb(15, 25, 47)
    private val cyan = Color.rgb(42, 190, 255)
    private val muted = Color.rgb(157, 178, 204)
    private val prefs by lazy { getSharedPreferences("lax_aura_settings", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var selectedGame = "Free Fire"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        selectedGame = prefs.getString("game", "Free Fire") ?: "Free Fire"
        showLogin()
    }

    private fun background(color: Int, radius: Float = 20f, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(2), dp(3), dp(2), dp(3))
        }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = background(Color.rgb(0, 126, 207), 16f)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener { action() }
    }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(muted)
        setTextColor(Color.WHITE)
        textSize = 15f
        singleLine = true
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = background(panel, 14f, Color.rgb(37, 69, 105))
    }

    private fun setup(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bg, Color.rgb(10, 28, 52), bg)
            )
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        root.addView(text("LAX  AURA  IOS 🧃", 25f, cyan, true))
        root.addView(text("GAMING COMPANION  •  v1.0.0", 11f, muted, true))
        addSpace(22)
        root.addView(text(title, 23f, Color.WHITE, true))
        root.addView(text(subtitle, 14f, muted))
        addSpace(18)
    }

    private fun addSpace(height: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = background(panel, 20f, Color.rgb(25, 55, 85))
    }

    private fun showLogin() {
        setup("Kích hoạt ứng dụng", "Nhập key được cấp bởi quản trị viên.")
        val c = card()
        c.addView(text("KEY KÍCH HOẠT", 12f, cyan, true))
        addSpace(8)
        val key = field("Ví dụ: LAX-XXXX-XXXX")
        c.addView(key, LinearLayout.LayoutParams(-1, dp(54)))
        addSpace(12)
        c.addView(button("Kiểm tra và kích hoạt") {
            val entered = key.text.toString().trim()
            if (entered.isEmpty()) {
                toast("Vui lòng nhập key.")
            } else if (BuildConfigValues.API_BASE_URL.isBlank()) {
                if (entered == "DEMO-1234") {
                    prefs.edit().putBoolean("demo_session", true).apply()
                    toast("Đã vào chế độ DEMO. Key này không phải xác thực thật.")
                    showDashboard()
                } else {
                    toast("Máy chủ chưa cấu hình. Chỉ key DEMO-1234 dùng được ở chế độ thử.")
                }
            } else {
                validateKey(entered)
            }
        })
        root.addView(c)
        addSpace(14)
        root.addView(text("Chế độ thử nghiệm: DEMO-1234. Đây không phải hệ thống bảo vệ bản quyền; cần cấu hình API HTTPS để xác thực key thật.", 12f, muted))
    }

    private fun validateKey(key: String) {
        thread {
            var message = "Không kết nối được máy chủ."
            var success = false
            try {
                val url = URL(BuildConfigValues.API_BASE_URL.trimEnd('/') + "/api/activate")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use {
                    it.write(JSONObject().put("key", key).put("app", "lax-aura-ios").toString().toByteArray(Charsets.UTF_8))
                }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "{}"
                val obj = JSONObject(body)
                success = conn.responseCode in 200..299 && obj.optBoolean("valid", false)
                message = obj.optString("message", if (success) "Kích hoạt thành công." else "Key không hợp lệ.")
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread {
                toast(message)
                if (success) {
                    prefs.edit().putBoolean("activated", true).putString("activation_key", key).apply()
                    showDashboard()
                }
            }
        }
    }

    private fun showDashboard() {
        setup("Bảng điều khiển", "Chọn game và quản lý cấu hình của ứng dụng.")
        val status = if (prefs.getBoolean("activated", false)) "Đã kích hoạt qua máy chủ"
                     else "Đang dùng chế độ DEMO"
        root.addView(text("●  $status", 13f, cyan, true))
        addSpace(14)
        root.addView(text("CHỌN TRÒ CHƠI", 12f, cyan, true))
        addSpace(8)
        val games = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        games.addView(gameButton("Free Fire"), LinearLayout.LayoutParams(0, dp(64), 1f))
        val spacer = View(this)
        games.addView(spacer, LinearLayout.LayoutParams(dp(10), 1))
        games.addView(gameButton("Free Fire MAX"), LinearLayout.LayoutParams(0, dp(64), 1f))
        root.addView(games)
        addSpace(8)
        root.addView(text("Đang chọn: $selectedGame", 14f, Color.WHITE, true))
        addSpace(18)
        val c = card()
        c.addView(text("CẤU HÌNH", 12f, cyan, true))
        addSpace(6)
        val config = field("Tên cấu hình (ví dụ: Mặc định)")
        config.setText(prefs.getString("config_name", "Mặc định"))
        c.addView(config, LinearLayout.LayoutParams(-1, dp(52)))
        addSpace(10)
        c.addView(button("Lưu cấu hình") {
            prefs.edit().putString("config_name", config.text.toString().trim().ifEmpty { "Mặc định" }).apply()
            toast("Đã lưu cấu hình trên thiết bị.")
        })
        root.addView(c)
        addSpace(14)
        root.addView(button("Kiểm tra cập nhật") { checkUpdates() })
        addSpace(8)
        root.addView(button("Mở game đã chọn") { openGame() })
        addSpace(8)
        root.addView(button("Đăng xuất / đổi key") {
            prefs.edit().remove("activated").remove("activation_key").remove("demo_session").apply()
            showLogin()
        })
        addSpace(16)
        root.addView(text("Lưu ý: app hiện chỉ lưu tên cấu hình và lựa chọn game. Không thay đổi tệp game hay dữ liệu trận đấu.", 12f, muted))
    }

    private fun gameButton(game: String): View {
        val b = TextView(this).apply {
            text = (if (selectedGame == game) "✓  " else "") + game
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(Color.WHITE)
            background = background(if (selectedGame == game) Color.rgb(0, 91, 145) else panel, 16f, cyan)
            setOnClickListener {
                selectedGame = game
                prefs.edit().putString("game", game).apply()
                showDashboard()
            }
        }
        return b
    }

    private fun checkUpdates() {
        if (BuildConfigValues.API_BASE_URL.isBlank()) {
            toast("Chưa cấu hình máy chủ cập nhật trong BuildConfigValues.kt.")
            return
        }
        thread {
            var message = "Không kiểm tra được cập nhật."
            try {
                val conn = (URL(BuildConfigValues.API_BASE_URL.trimEnd('/') + "/api/version").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000
                    readTimeout = 7000
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(body)
                message = "Phiên bản mới nhất: ${obj.optString("version", "không rõ")}"
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { toast(message) }
        }
    }

    private fun openGame() {
        val packageNames = if (selectedGame == "Free Fire MAX")
            listOf("com.dts.freefiremax", "com.dts.freefiremaxth")
        else listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (pkg in packageNames) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                return
            }
        }
        toast("Không tìm thấy game. Hãy cài game chính thức trước.")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

private object BuildConfigValues {
    // Để trống khi chưa có backend. Khi có máy chủ, dùng URL HTTPS, ví dụ https://api.example.com
    const val API_BASE_URL = ""
}
