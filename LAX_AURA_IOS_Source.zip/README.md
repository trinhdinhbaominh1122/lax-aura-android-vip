# LAX AURA IOS 🧃 — Android source

Ứng dụng Android mẫu Kotlin, giao diện tối neon xanh dương/đen.

## Có gì trong bản source
- Màn hình nhập key.
- Chế độ demo `DEMO-1234` để kiểm tra luồng giao diện (KHÔNG phải bảo mật thật).
- Chọn Free Fire / Free Fire MAX và lưu lựa chọn.
- Lưu tên cấu hình cục bộ bằng SharedPreferences.
- Mở game nếu đã cài và Android tìm thấy package.
- Khung gọi API HTTPS để xác thực key và kiểm tra phiên bản.

## Giới hạn quan trọng
- Xác thực key thật và cập nhật từ máy chủ chưa hoạt động cho đến khi bạn có backend HTTPS.
- Đổi `API_BASE_URL` trong `app/src/main/java/com/laxaura/ios/MainActivity.kt` thành URL máy chủ của bạn.
- API kích hoạt dự kiến: `POST /api/activate`, JSON gửi `{"key":"...","app":"lax-aura-ios"}`, phản hồi JSON `{"valid":true,"message":"Kích hoạt thành công"}`.
- API phiên bản dự kiến: `GET /api/version`, phản hồi JSON `{"version":"1.0.1"}`.
- Không đặt bí mật quản trị hoặc master key bên trong APK. Xác thực và thu hồi key phải được thực hiện phía máy chủ qua HTTPS.
- Bản này không chỉnh sửa game, không can thiệp bộ nhớ/trận đấu, không cung cấp chức năng gian lận.
- Package name dự kiến của Free Fire có thể khác theo quốc gia/phiên bản. Nếu nút mở game không tìm thấy, cần xác định package name chính xác trên máy.

## Build APK chỉ bằng điện thoại Android (GitHub Actions)
1. Tạo tài khoản GitHub nếu chưa có.
2. Tạo repository mới, ví dụ `lax-aura-android`.
3. Upload toàn bộ nội dung ZIP đã giải nén lên repository (giữ đúng thư mục và đường dẫn).
4. Mở tab **Actions** và cho phép workflow chạy nếu GitHub yêu cầu.
5. Workflow sẽ build APK debug; vào lần chạy thành công, kéo xuống phần **Artifacts** và tải `LAX-AURA-IOS-debug-apk`.
6. Giải nén file artifact tải về, mở APK trên Android và cho phép cài ứng dụng từ nguồn đó nếu Android hỏi.

## Build bằng máy tính
Cần JDK 17 và Gradle 8.9; chạy:
`gradle assembleDebug`
APK sẽ ở `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý build
Android Gradle Plugin 8.7.3 cần JDK 17. Không dùng APK này để thay thế hoặc giả mạo ứng dụng chính thức.
